"""Offline placeholder for the requests name."""

__version__ = "2.31.0"
