"""Offline placeholder for the requests name."""

__version__ = "2.25.0"
